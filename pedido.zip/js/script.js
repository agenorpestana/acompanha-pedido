

        function handleSelectChange(selectElement) {
            const selectedValue = selectElement.value;
            const orderId = selectElement.dataset.orderId;

            const xhr = new XMLHttpRequest();
            xhr.open("POST", "pedido.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        const row = selectElement.closest('tr');
                        row.querySelector('td[data-label="Status do Pedido"]').innerText = selectedValue;
                        selectElement.value = "alterar_status";
                        updateRowColor(row, selectedValue);
                        alert("Status atualizado com sucesso!");
                    } else {
                        alert("Erro ao atualizar o status do pedido.");
                    }
                } else if (xhr.readyState === 4) {
                    alert("Erro ao atualizar o status do pedido.");
                }
            };
            xhr.send(`update=1&id=${orderId}&status_pedido=${selectedValue}`);
        }

        function updateRowColor(row, status) {
            row.classList.remove('status-pedido-feito', 'status-em-producao', 'status-concluido');
            const normalizedStatus = normalizeStatus(status);
            row.classList.add(`status-${normalizedStatus}`);
        }

        function normalizeStatus(status) {
            status = status.toLowerCase();
            status = status.replace(' ', '-');
            status = status.replace(/[áéíóúãõç]/g, function(match) {
                const map = { 'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ú': 'u', 'ã': 'a', 'õ': 'o', 'ç': 'c' };
                return map[match];
            });
            return status;
        }

        function resetSelectOption() {
            const selects = document.querySelectorAll("select[name='status_pedido']");
            selects.forEach(select => {
                if (select.value === "Pedido Feito" || select.value === "Em Producao" || select.value === "Concluido") {
                    select.value = "alterar_status";
                }
            });
        }

        window.onload = function() {
            resetSelectOption();
        };

        function openEditForm(id, data_pedido, prazo_entrega, nome_cliente, contato_cliente, descricao_pedido, status_pedido) {
            document.getElementById('edit-id').value = id;
            document.getElementById('edit-data_pedido').value = data_pedido;
            document.getElementById('edit-prazo_entrega').value = prazo_entrega;
            document.getElementById('edit-nome_cliente').value = nome_cliente;
            document.getElementById('edit-contato_cliente').value = contato_cliente;
            document.getElementById('edit-descricao_pedido').value = descricao_pedido;
            document.getElementById('edit-status_pedido').value = status_pedido;
            document.getElementById('edit-form-container').style.display = 'block';
        }

        function closeForm() {
            document.getElementById('form-container').style.display = 'none';
        }

        function closeEditForm() {
            document.getElementById('edit-form-container').style.display = 'none';
        }

        function deletePedido(id) {
            if (confirm("Tem certeza que deseja deletar este pedido?")) {
                const xhr = new XMLHttpRequest();
                xhr.open("POST", "pedido.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            const row = document.querySelector(`tr[data-order-id="${id}"]`);
                            row.remove();
                            alert("Pedido deletado com sucesso!");
                        } else {
                            alert(response.message);
                        }
                    } else if (xhr.readyState === 4) {
                        alert("Erro ao deletar o pedido.");
                    }
                };
                xhr.send(`delete=1&id=${id}`);
            }
        }
 