<?php
require_once 'config.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

function normalizeStatus($status) {
    $status = strtolower($status);
    $status = str_replace(' ', '-', $status);
    $status = str_replace(['á', 'é', 'í', 'ó', 'ú', 'ã', 'õ', 'ç'], ['a', 'e', 'i', 'o', 'u', 'a', 'o', 'c'], $status);
    return $status;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if (isset($_POST['add'])) {
            $data_pedido = $_POST['data_pedido'];
            $prazo_entrega = $_POST['prazo_entrega'];
            $nome_cliente = $_POST['nome_cliente'];
            $contato_cliente = $_POST['contato_cliente'];
            $descricao_pedido = $_POST['descricao_pedido'];
            $status_pedido = $_POST['status_pedido'];

            $query = "INSERT INTO pedidos (data_pedido, prazo_entrega, nome_cliente, contato_cliente, descricao_pedido, status_pedido) VALUES (:data_pedido, :prazo_entrega, :nome_cliente, :contato_cliente, :descricao_pedido, :status_pedido)";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':data_pedido', $data_pedido);
            $stmt->bindParam(':prazo_entrega', $prazo_entrega);
            $stmt->bindParam(':nome_cliente', $nome_cliente);
            $stmt->bindParam(':contato_cliente', $contato_cliente);
            $stmt->bindParam(':descricao_pedido', $descricao_pedido);
            $stmt->bindParam(':status_pedido', $status_pedido);
            $stmt->execute();
        } elseif (isset($_POST['update'])) {
            $id = $_POST['id'];
            $status_pedido = $_POST['status_pedido'];

            $query = "UPDATE pedidos SET status_pedido = :status_pedido WHERE id = :id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':status_pedido', $status_pedido);
            $stmt->bindParam(':id', $id);
            $stmt->execute();

            echo json_encode(['success' => true, 'message' => 'Status atualizado com sucesso']);
            exit;
        } elseif (isset($_POST['edit'])) {
            $id = $_POST['id'];
            $data_pedido = $_POST['data_pedido'];
            $prazo_entrega = $_POST['prazo_entrega'];
            $nome_cliente = $_POST['nome_cliente'];
            $contato_cliente = $_POST['contato_cliente'];
            $descricao_pedido = $_POST['descricao_pedido'];
            $status_pedido = $_POST['status_pedido'];

            $query = "UPDATE pedidos SET data_pedido = :data_pedido, prazo_entrega = :prazo_entrega, nome_cliente = :nome_cliente, contato_cliente = :contato_cliente, descricao_pedido = :descricao_pedido, status_pedido = :status_pedido WHERE id = :id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':data_pedido', $data_pedido);
            $stmt->bindParam(':prazo_entrega', $prazo_entrega);
            $stmt->bindParam(':nome_cliente', $nome_cliente);
            $stmt->bindParam(':contato_cliente', $contato_cliente);
            $stmt->bindParam(':descricao_pedido', $descricao_pedido);
            $stmt->bindParam(':status_pedido', $status_pedido);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
        if ($_SESSION['usuario']['tipo'] != 'admin') {
            echo json_encode(['success' => false, 'message' => 'Você não tem permissão para deletar pedidos.']);
            exit;
        }
    
        $id = $_POST['id'];
    
        $query = "DELETE FROM pedidos WHERE id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    
        echo json_encode(['success' => true, 'message' => 'Pedido deletado com sucesso']);
        exit;
    }
    
    $status_filter = isset($_GET['status_filter']) ? $_GET['status_filter'] : '';
    
    $query = "SELECT * FROM pedidos";
    if ($status_filter) {
        $query .= " WHERE status_pedido = :status_filter";
    }
    $stmt = $conn->prepare($query);
    if ($status_filter) {
        $stmt->bindParam(':status_filter', $status_filter);
    }
    $stmt->execute();
    
    $pedidos = $stmt->fetchAll();
    
}

$status_filter = isset($_GET['status_filter']) ? $_GET['status_filter'] : '';

$query = "SELECT * FROM pedidos";
if ($status_filter) {
    $query .= " WHERE status_pedido = :status_filter";
}
$query .= " ORDER BY data_pedido DESC";

$stmt = $conn->prepare($query);
if ($status_filter) {
    $stmt->bindParam(':status_filter', $status_filter);
}
$stmt->execute();
$pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acompanhamento de Pedidos</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/script.js"></script>
    
</head>
<body>
    <h1>Acompanhamento de Pedidos</h1>
   
        <div class="button-container">
        <button onclick="document.getElementById('form-container').style.display='block'">Adicionar Pedido</button>
            
        </div>
        <div class="button-voltar-container">
            <a href="index.php">Voltar</a>
        </div>
        
    <!-- <button onclick="document.getElementById('form-container').style.display='block'">Adicionar Pedido</button> -->
    <div id="form-container" class="form-container" style="display: none;">
        <form method="POST" action="pedido.php">
            <input type="hidden" name="add" value="1">
            <label for="data_pedido">Data do Pedido:</label>
            <input type="date" id="data_pedido" name="data_pedido" required><br>
            <label for="prazo_entrega">Prazo de Entrega:</label>
            <input type="date" id="prazo_entrega" name="prazo_entrega" required><br>
            <label for="nome_cliente">Nome do Cliente:</label>
            <input type="text" id="nome_cliente" name="nome_cliente" required><br>
            <label for="contato_cliente">Contato do Cliente:</label>
            <input type="text" id="contato_cliente" name="contato_cliente" required><br>
            <label for="descricao_pedido">Descrição do Pedido:</label>
            <textarea id="descricao_pedido" name="descricao_pedido" required></textarea><br>
            <label for="status_pedido">Status do Pedido:</label>
            <select id="status_pedido" name="status_pedido" required>
                <option value="Pedido Feito">Pedido Feito</option>
                <option value="Em Producao">Em Produção</option>
                <option value="Concluido">Concluído</option>
            </select><br>
            <div class="button-container">
                <button type="submit" class="btn">Adicionar</button>
                <button type="button" class="btn cancel" onclick="closeForm()">Cancelar</button>
            </div>
        </form>
    </div>
    <div id="edit-form-container" class="form-container" style="display: none;">
        <form method="POST" action="pedido.php">
            <input type="hidden" name="edit" value="1">
            <input type="hidden" id="edit-id" name="id">
            <label for="edit-data_pedido">Data do Pedido:</label>
            <input type="date" id="edit-data_pedido" name="data_pedido" required><br>
            <label for="edit-prazo_entrega">Prazo de Entrega:</label>
            <input type="date" id="edit-prazo_entrega" name="prazo_entrega" required><br>
            <label for="edit-nome_cliente">Nome do Cliente:</label>
            <input type="text" id="edit-nome_cliente" name="nome_cliente" required><br>
            <label for="edit-contato_cliente">Contato do Cliente:</label>
            <input type="text" id="edit-contato_cliente" name="contato_cliente" required><br>
            <label for="edit-descricao_pedido">Descrição do Pedido:</label>
            <textarea id="edit-descricao_pedido" name="descricao_pedido" required></textarea><br>
            <label for="edit-status_pedido">Status do Pedido:</label>
            <select id="edit-status_pedido" name="status_pedido" required>
                <option value="Pedido Feito">Pedido Feito</option>
                <option value="Em Producao">Em Produção</option>
                <option value="Concluido">Concluído</option>
            </select><br>
            <div class="button-container">
                <button type="submit" class="btn">Salvar</button>
                <button type="button" class="btn cancel" onclick="closeEditForm()">Cancelar</button>
            </div>
        </form>
    </div>
    <form method="GET" action="pedido.php" class="filter-form">
        <label for="status_filter">Filtrar por Status:</label>
        <select id="status_filter" name="status_filter" onchange="this.form.submit()">
            <option value="">Todos</option>
            <option value="Pedido Feito" <?php echo $status_filter == 'Pedido Feito' ? 'selected' : ''; ?>>Pedido Feito</option>
            <option value="Em Producao" <?php echo $status_filter == 'Em Producao' ? 'selected' : ''; ?>>Em Produção</option>
            <option value="Concluido" <?php echo $status_filter == 'Concluido' ? 'selected' : ''; ?>>Concluído</option>
        </select>
    </form>
    <table>
        <thead>
            <tr>
                <th>Data do Pedido</th>
                <th>Prazo de Entrega</th>
                <th>Nome do Cliente</th>
                <th>Contato do Cliente</th>
                <th>Descrição do Pedido</th>
                <th>Status do Pedido</th>
                <th>Opções</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pedidos as $pedido): ?>
            <tr class="status-<?php echo normalizeStatus($pedido['status_pedido']); ?>" data-order-id="<?php echo $pedido['id']; ?>">
                <td data-label="Data do Pedido"><?php echo date('d/m/Y', strtotime($pedido['data_pedido'])); ?></td>
                <td data-label="Prazo de Entrega"><?php echo date('d/m/Y', strtotime($pedido['prazo_entrega'])); ?></td>
                <td data-label="Nome do Cliente"><?php echo $pedido['nome_cliente']; ?></td>
                <td data-label="Contato do Cliente"><?php echo $pedido['contato_cliente']; ?></td>
                <td data-label="Descrição do Pedido"><?php echo $pedido['descricao_pedido']; ?></td>
                <td data-label="Status do Pedido"><?php echo $pedido['status_pedido']; ?></td>
                <td>
                <div class="button-container">
                    <select name="status_pedido" data-order-id="<?php echo $pedido['id']; ?>" onchange="handleSelectChange(this)">
                        <option value="alterar_status">Alterar Status</option>
                        <option value="Pedido Feito" <?php echo $pedido['status_pedido'] == 'Pedido Feito' ? 'selected' : ''; ?>>Pedido Feito</option>
                        <option value="Em Producao" <?php echo $pedido['status_pedido'] == 'Em Producao' ? 'selected' : ''; ?>>Em Produção</option>
                        <option value="Concluido" <?php echo $pedido['status_pedido'] == 'Concluido' ? 'selected' : ''; ?>>Concluído</option>
                    </select>
                    
                    
                        <button class="btn" onclick="openEditForm('<?php echo $pedido['id']; ?>', '<?php echo $pedido['data_pedido']; ?>', '<?php echo $pedido['prazo_entrega']; ?>', '<?php echo $pedido['nome_cliente']; ?>', '<?php echo $pedido['contato_cliente']; ?>', '<?php echo $pedido['descricao_pedido']; ?>', '<?php echo $pedido['status_pedido']; ?>')">Editar</button>
                            <?php if ($_SESSION['usuario']['tipo'] == 'admin'): ?>
                                <button class="btn cancel" onclick="deletePedido('<?php echo $pedido['id']; ?>')">Deletar</button>
                            <?php endif; ?>
                <div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
</body>
</html>
